<?php
/**
 * Plugin Name: MOTIF SEO Tweaks
 * Plugin URI:  https://motif-jeonju.com
 * Description: 모티프 사이트 SEO 보정 — 저자 프로필(이름·사진·소개) 적용, 빈 이미지 alt 자동 채움, FAQPage 스키마 자동 출력, LocalBusiness 스키마 보정(sameAs·areaServed·좌표), 홈 Article 스키마 제거, 보안 헤더, /llms.txt 제공.
 * Version:     1.0.0
 * Author:      MOTIF
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MOTIF_ST_AUTHOR_ID', 1 );
define( 'MOTIF_ST_AVATAR_URL', 'https://motif-jeonju.com/wp-content/uploads/2026/11/martin-profile-600.jpg' );
define( 'MOTIF_ST_PROFILE_VERSION', '1' );

/* ---------------------------------------------------------------------
 * 1) 저자 프로필 1회 갱신: 표시 이름 · 닉네임 · 소개 · 사이트 URL
 * ------------------------------------------------------------------- */
add_action( 'init', 'motif_st_apply_author_profile', 5 );
function motif_st_apply_author_profile() {
	if ( get_option( 'motif_st_profile_applied' ) === MOTIF_ST_PROFILE_VERSION ) {
		return;
	}
	if ( ! get_userdata( MOTIF_ST_AUTHOR_ID ) ) {
		return;
	}
	$bio = '전주 모티프(MOTIF) 대표 · 오너 틴터. 솔라가드 THE LX 전북 유일 특화샵이자 XPEL FinalFit 전라도 유일 공식 인증점을 운영하며, 10년 경력으로 썬팅·PPF·가죽코팅 전 과정을 직접 시공합니다. 하루 한두 대, 100% 예약제. 측정 기준(IWFA·NFRC)과 제조원이 검증된 필름만 다룹니다.';
	$result = wp_update_user(
		array(
			'ID'           => MOTIF_ST_AUTHOR_ID,
			'display_name' => '마틴 (모티프 대표)',
			'nickname'     => '마틴',
			'first_name'   => '마틴',
			'last_name'    => '',
			'user_url'     => 'https://motif-jeonju.com',
			'description'  => $bio,
		)
	);
	if ( ! is_wp_error( $result ) ) {
		update_option( 'motif_st_profile_applied', MOTIF_ST_PROFILE_VERSION );
	}
}

/* ---------------------------------------------------------------------
 * 2) 저자 아바타를 Gravatar 대신 업로드한 프로필 사진으로
 * ------------------------------------------------------------------- */
add_filter( 'pre_get_avatar_data', 'motif_st_avatar_data', 10, 2 );
function motif_st_avatar_data( $args, $id_or_email ) {
	$uid = 0;
	if ( is_numeric( $id_or_email ) ) {
		$uid = (int) $id_or_email;
	} elseif ( $id_or_email instanceof WP_User ) {
		$uid = (int) $id_or_email->ID;
	} elseif ( $id_or_email instanceof WP_Post ) {
		$uid = (int) $id_or_email->post_author;
	} elseif ( $id_or_email instanceof WP_Comment ) {
		$uid = (int) $id_or_email->user_id;
		if ( ! $uid && ! empty( $id_or_email->comment_author_email ) ) {
			$u   = get_user_by( 'email', $id_or_email->comment_author_email );
			$uid = $u ? (int) $u->ID : 0;
		}
	} elseif ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
		$u   = get_user_by( 'email', $id_or_email );
		$uid = $u ? (int) $u->ID : 0;
	}
	if ( $uid === MOTIF_ST_AUTHOR_ID ) {
		$args['url']          = MOTIF_ST_AVATAR_URL;
		$args['found_avatar'] = true;
	}
	return $args;
}

/* ---------------------------------------------------------------------
 * 3) 빈 이미지 alt 자동 채움 (미디어 alt → 직전 소제목 → 글 제목)
 * ------------------------------------------------------------------- */
add_filter( 'the_content', 'motif_st_fill_empty_img_alt', 20 );
function motif_st_fill_empty_img_alt( $content ) {
	if ( is_admin() || ! is_singular() || empty( $content ) ) {
		return $content;
	}
	$post_title   = wp_strip_all_tags( get_the_title() );
	$last_heading = '';
	$index        = 0;

	return preg_replace_callback(
		'#(<h[23][^>]*>(.*?)</h[23]>)|(<img\b[^>]*>)#is',
		function ( $m ) use ( &$last_heading, &$index, $post_title ) {
			if ( ! empty( $m[1] ) ) {
				$h = trim( wp_strip_all_tags( $m[2] ) );
				$h = preg_replace( '/^Q\d*\.\s*/u', '', $h );
				if ( mb_strlen( $h ) > 3 ) {
					$last_heading = $h;
				}
				return $m[0];
			}
			$img = $m[3];
			if ( preg_match( '/\salt=("|\')(?!\1)[^"\']+\1/i', $img ) ) {
				return $img;
			}
			$index++;
			$alt = '';
			if ( preg_match( '/wp-image-(\d+)/', $img, $idm ) ) {
				$alt = trim( (string) get_post_meta( (int) $idm[1], '_wp_attachment_image_alt', true ) );
			}
			if ( $alt === '' && $last_heading !== '' ) {
				$alt = $last_heading . ' — ' . $post_title . ' (모티프 시공 사진)';
			}
			if ( $alt === '' ) {
				$alt = $post_title . ' — 모티프 시공 사진 ' . $index;
			}
			$alt = esc_attr( mb_substr( $alt, 0, 120 ) );
			if ( preg_match( '/\salt=("|\')\1/i', $img ) ) {
				return preg_replace( '/\salt=("|\')\1/i', ' alt="' . $alt . '"', $img, 1 );
			}
			return preg_replace( '/<img\b/i', '<img alt="' . $alt . '"', $img, 1 );
		},
		$content
	);
}

/* ---------------------------------------------------------------------
 * 4) FAQPage JSON-LD 자동 출력 (본문 "자주 묻는 질문" 섹션 기반)
 * ------------------------------------------------------------------- */
add_action( 'wp_footer', 'motif_st_output_faq_schema', 5 );
function motif_st_output_faq_schema() {
	if ( ! is_singular( 'post' ) ) {
		return;
	}
	global $post;
	$content = $post->post_content;
	if ( stripos( $content, 'FAQPage' ) !== false ) {
		return;
	}
	if ( ! preg_match( '#<h2[^>]*>[^<]*(자주 묻는 질문|FAQ)[^<]*</h2>(.*)$#isu', $content, $sec ) ) {
		return;
	}
	$section = $sec[2];
	$next_h2 = stripos( $section, '<h2' );
	if ( $next_h2 !== false ) {
		$section = substr( $section, 0, $next_h2 );
	}
	preg_match_all( '#<h3[^>]*>(.*?)</h3>\s*(?:<!--[^>]*-->\s*)*<p[^>]*>(.*?)</p>#isu', $section, $pairs, PREG_SET_ORDER );
	if ( count( $pairs ) < 2 ) {
		return;
	}
	$items = array();
	foreach ( $pairs as $p ) {
		$q = trim( preg_replace( '/^Q\d*\.\s*/u', '', wp_strip_all_tags( $p[1] ) ) );
		$a = trim( preg_replace( '/^A\d*\.\s*/u', '', wp_strip_all_tags( $p[2] ) ) );
		if ( $q === '' || $a === '' ) {
			continue;
		}
		$items[] = array(
			'@type'          => 'Question',
			'name'           => $q,
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $a,
			),
		);
	}
	if ( count( $items ) < 2 ) {
		return;
	}
	$schema = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'FAQPage',
		'mainEntity' => $items,
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}

/* ---------------------------------------------------------------------
 * 5) Rank Math JSON-LD 보정
 *    - 좌표 공백 제거, Organization에 sameAs/areaServed/priceRange/founder
 *    - 업종을 AutoRepair(LocalBusiness 하위)로 구체화
 *    - 홈·페이지의 Article 스키마 제거, Person에 jobTitle 추가
 * ------------------------------------------------------------------- */
add_filter( 'rank_math/json_ld', 'motif_st_fix_json_ld', 99, 2 );
function motif_st_fix_json_ld( $data, $jsonld = null ) {
	if ( ! is_array( $data ) ) {
		return $data;
	}
	$remove = array();
	foreach ( $data as $key => $entity ) {
		if ( ! is_array( $entity ) ) {
			continue;
		}
		// 좌표 공백
		if ( isset( $entity['geo'] ) && is_array( $entity['geo'] ) ) {
			foreach ( array( 'latitude', 'longitude' ) as $c ) {
				if ( isset( $entity['geo'][ $c ] ) ) {
					$entity['geo'][ $c ] = trim( (string) $entity['geo'][ $c ] );
				}
			}
		}
		if ( isset( $entity['hasMap'] ) && is_string( $entity['hasMap'] ) ) {
			$entity['hasMap'] = str_replace( ' ', '', $entity['hasMap'] );
		}
		if ( isset( $entity['description'] ) && is_string( $entity['description'] ) ) {
			$entity['description'] = trim( $entity['description'] );
		}
		// Organization / LocalBusiness
		if ( isset( $entity['@id'] ) && is_string( $entity['@id'] ) && substr( $entity['@id'], -13 ) === '#organization' ) {
			$entity['@type']      = array( 'AutoRepair', 'LocalBusiness', 'Organization' );
			$entity['name']       = isset( $entity['name'] ) ? $entity['name'] : 'MOTIF';
			$entity['alternateName'] = array( '모티프', '전주 모티프', 'MOTIF Jeonju' );
			$entity['sameAs']     = array(
				'https://blog.naver.com/12rrrryn',
				'https://motif-jeonju.tistory.com',
				'https://smartstore.naver.com/windowtinting',
				'https://map.naver.com/p/entry/place/38257851',
				'https://pf.kakao.com/_IJxmgb',
			);
			$entity['areaServed'] = array(
				array( '@type' => 'City', 'name' => '전주시' ),
				array( '@type' => 'City', 'name' => '익산시' ),
				array( '@type' => 'City', 'name' => '군산시' ),
				array( '@type' => 'City', 'name' => '정읍시' ),
				array( '@type' => 'AdministrativeArea', 'name' => '전북특별자치도' ),
			);
			$entity['priceRange'] = '₩₩₩';
			$entity['founder']    = array(
				'@type'    => 'Person',
				'name'     => '마틴',
				'jobTitle' => '대표 · 오너 틴터',
				'url'      => home_url( '/author/kim798023/' ),
			);
			$entity['knowsAbout'] = array( '자동차 윈도우 틴팅', 'PPF(페인트 보호 필름)', '가죽코팅', '유리막 코팅', '신차패키지', '솔라가드 THE LX', 'XPEL' );
			if ( empty( $entity['telephone'] ) ) {
				$entity['telephone'] = '+82-10-4814-4506';
			}
		}
		// Person (저자)
		if ( isset( $entity['@type'] ) && $entity['@type'] === 'Person' ) {
			$entity['jobTitle']  = '모티프 대표 · 오너 틴터';
			$entity['knowsAbout'] = array( '자동차 윈도우 틴팅', 'PPF', '가죽코팅', '신차패키지' );
			if ( isset( $entity['image']['url'] ) && strpos( $entity['image']['url'], 'gravatar' ) !== false ) {
				$entity['image']['url']        = MOTIF_ST_AVATAR_URL;
				$entity['image']['@id']        = MOTIF_ST_AVATAR_URL;
				$entity['image']['contentUrl'] = MOTIF_ST_AVATAR_URL;
			}
		}
		// 홈·일반 페이지에 붙은 Article 제거
		if ( ( is_front_page() || is_page() ) && isset( $entity['@type'] ) && $entity['@type'] === 'Article' ) {
			$remove[] = $key;
		}
		$data[ $key ] = $entity;
	}
	foreach ( $remove as $k ) {
		unset( $data[ $k ] );
	}
	return $data;
}

/* ---------------------------------------------------------------------
 * 6) 보안 헤더
 * ------------------------------------------------------------------- */
add_action( 'send_headers', 'motif_st_security_headers' );
function motif_st_security_headers() {
	if ( headers_sent() ) {
		return;
	}
	header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains' );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
}

/* ---------------------------------------------------------------------
 * 7) /llms.txt — AI 검색엔진용 사이트 안내 (동적 생성, 리라이트 플러시 불필요)
 * ------------------------------------------------------------------- */
add_action( 'init', 'motif_st_serve_llms_txt', 1 );
function motif_st_serve_llms_txt() {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ) : '';
	if ( $path !== '/llms.txt' ) {
		return;
	}
	nocache_headers();
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );

	$lines   = array();
	$lines[] = '# MOTIF (모티프) — 전주 썬팅·PPF·가죽코팅·신차패키지 전문점';
	$lines[] = '';
	$lines[] = '> 전주 덕진구 정여립로 1104. 솔라가드 THE LX 전북 유일 특화샵, XPEL FinalFit 전라도 유일 공식 인증점. 10년 경력 오너 틴터가 하루 한두 대만 직접 시공하는 100% 예약제 디테일링 샵. 측정 기준(IWFA·NFRC·ISO 9050)과 제조원이 검증된 필름만 다룹니다.';
	$lines[] = '';
	$lines[] = '- 전화: 010-4814-4506';
	$lines[] = '- 네이버 톡톡: https://talk.naver.com/WCA4KN';
	$lines[] = '- 카카오 채널: https://pf.kakao.com/_IJxmgb';
	$lines[] = '- 시공 지역: 전주 · 익산 · 군산 · 정읍 등 전북 전역';
	$lines[] = '';
	$lines[] = '## 기준 문서 (측정·정의 레퍼런스)';
	$hubs    = array(
		'전주썬팅 메인 기준서 — 필름 구조 4분류·측정 기준' => 51,
		'솔라가드 THE LX 기준서 — 농도별 VLT·TSER·10년 보증' => 68,
		'솔라가드 제니스 IR 기준서 — 나노 세라믹·전파 간섭 없음' => 58,
		'전주 PPF 기준서 — XPEL 라인업·두께·보증' => 83,
		'전주 가죽코팅 기준서 — 야와라·관리 주기' => 90,
		'테슬라 썬팅 기준서' => 77,
		'썬팅 선택 체크리스트 5문항' => 591,
		'솔라가드 등급 체계' => 484,
		'SIRR·IRER 적외선 지표' => 600,
		'내부 반사율(VLR in)' => 583,
		'신차패키지 견적 설계 기준' => 566,
	);
	foreach ( $hubs as $label => $pid ) {
		$url = get_permalink( $pid );
		if ( $url ) {
			$lines[] = '- [' . $label . '](' . $url . ')';
		}
	}
	$lines[] = '';
	$lines[] = '## 카테고리';
	foreach ( get_categories( array( 'hide_empty' => true ) ) as $cat ) {
		if ( $cat->slug === 'uncategorized' ) {
			continue;
		}
		$lines[] = '- [' . $cat->name . '](' . get_category_link( $cat ) . ') — ' . $cat->count . '편';
	}
	$lines[] = '';
	$lines[] = '## 최근 글';
	$recent = get_posts( array( 'numberposts' => 25, 'post_status' => 'publish' ) );
	foreach ( $recent as $p ) {
		$lines[] = '- [' . wp_strip_all_tags( get_the_title( $p ) ) . '](' . get_permalink( $p ) . ')';
	}
	$lines[] = '';
	$lines[] = '## 견적·상담 도구';
	$lines[] = '- 썬팅 자동 견적: https://motif-tintingquate.netlify.app/';
	$lines[] = '- PPF 견적: https://motif-ppf.netlify.app/';
	$lines[] = '- 신차패키지 견적: https://splendid-bonbon-24d4fc.netlify.app/';
	$lines[] = '- 썬팅 성향 진단 12문항: https://motif-tinting-test.netlify.app/';
	$lines[] = '';
	$lines[] = '## 관련 채널';
	$lines[] = '- 네이버 블로그: https://blog.naver.com/12rrrryn';
	$lines[] = '- 티스토리: https://motif-jeonju.tistory.com';
	$lines[] = '- 스마트스토어: https://smartstore.naver.com/windowtinting';
	$lines[] = '- 사이트맵: ' . home_url( '/sitemap_index.xml' );

	echo implode( "\n", $lines ) . "\n";
	exit;
}
